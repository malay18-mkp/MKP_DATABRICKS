# Databricks notebook source
# DBTITLE 1,Overview
# MAGIC %md
# MAGIC # 01 - Data preparation and training
# MAGIC
# MAGIC Prepares COCO128 in a Unity Catalog volume, trains YOLO11n with MLflow tracking, registers the custom pyfunc model to Unity Catalog, then tags the new version and points the **`challenger`** alias at it.
# MAGIC
# MAGIC **Compute:** Serverless GPU (A10 or H100) with base environment **AI v6**.
# MAGIC
# MAGIC **Next:** `02_evaluation`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./00_config

# COMMAND ----------

# DBTITLE 1,Load Shared Helpers
# MAGIC %run ./00_helpers

# COMMAND ----------

# DBTITLE 1,Create Schema, Volume and Project Folders
# External artifact sources, pinned to fixed versions. For production or
# network-restricted workspaces, stage these in a UC volume or internal mirror.
dbutils.widgets.text("model_source_url", "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolo11n.pt", "Pretrained Model URL")
dbutils.widgets.text("dataset_config_url", "https://raw.githubusercontent.com/ultralytics/ultralytics/v8.3.204/ultralytics/cfg/datasets/coco128.yaml", "Dataset Config URL")

spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{catalog_name}`.`{schema_name}`")
print(f"[OK] Schema: {catalog_name}.{schema_name}")

spark.sql(f"CREATE VOLUME IF NOT EXISTS `{catalog_name}`.`{schema_name}`.`{volume_name}`")
print(f"[OK] Volume: {catalog_name}.{schema_name}.{volume_name}")

os.makedirs(f'{project_location}runs/', exist_ok=True)       # Training runs
os.makedirs(f'{project_location}data/', exist_ok=True)       # Dataset storage
os.makedirs(f'{project_location}raw_model/', exist_ok=True)  # Pretrained models
print(f"[OK] Project directories ready under {project_location}")

# COMMAND ----------

# DBTITLE 1,Download YOLO11n to Unity Catalog Volume
pretrained_model_path = f"{project_location}raw_model/yolo11n.pt"
download_file(dbutils.widgets.get("model_source_url"), pretrained_model_path, "YOLO11n model")
print(f"\n[OK] Pretrained model ready at: {pretrained_model_path}")

# COMMAND ----------

# DBTITLE 1,Download and Prepare Dataset
os.makedirs(f'{project_location}data/coco128', exist_ok=True)

config_path = f"{project_location}data/coco128.yaml"
download_file(dbutils.widgets.get("dataset_config_url"), config_path, "COCO128 config")

with open(config_path, 'r') as f:
    data = yaml.safe_load(f)

print(f"\n[Dataset Configuration]")
print(f"   Dataset: {data.get('path', 'coco128')}")
print(f"   Classes: {data.get('nc', 'unknown')}")
print(f"   Download URL: {data.get('download', 'N/A')}")

data['path'] = f"{project_location}data/coco128"

dataset_images_dir = f"{project_location}data/coco128/images/train2017"
if os.path.exists(dataset_images_dir) and len(os.listdir(dataset_images_dir)) > 0:
    print(f"\n[INFO] Dataset already exists ({len(os.listdir(dataset_images_dir))} images) - skipping download")
else:
    download_and_extract_dataset(data['download'], f"{project_location}data")

data_yaml_path = f"{project_location}data/coco128.yaml"
with open(data_yaml_path, 'w') as f:
    yaml.dump(data, f, default_flow_style=False)
print(f"\n[OK] Dataset configuration saved: {data_yaml_path}")

# COMMAND ----------

# DBTITLE 1,Create Train/Val/Test Splits
source_images_dir = f"{project_location}data/coco128/images/train2017"
source_labels_dir = f"{project_location}data/coco128/labels/train2017"
base_images_dir = f"{project_location}data/coco128/images"
base_labels_dir = f"{project_location}data/coco128/labels"

train_dir, val_dir, test_dir = (f"{base_images_dir}/{s}" for s in ("train", "val", "test"))

# Skip if splits already exist (deterministic with seed=42)
if all(os.path.isdir(d) and len(os.listdir(d)) > 0 for d in (train_dir, val_dir, test_dir)):
    train_size, val_size, test_size = (len(os.listdir(d)) for d in (train_dir, val_dir, test_dir))
    print("[INFO] Splits already exist - skipping re-split")
else:
    train_size, val_size, test_size = split_dataset(
        source_images_dir=source_images_dir,
        source_labels_dir=source_labels_dir,
        base_images_dir=base_images_dir,
        base_labels_dir=base_labels_dir,
        train_ratio=0.625,
        val_ratio=0.1875,
        random_seed=42
    )

print(f"\nSplit summary: Train={train_size}, Val={val_size}, Test={test_size} (seed=42)")

# COMMAND ----------

# DBTITLE 1,Update data.yaml for Splits
with open(data_yaml_path, 'r') as f:
    yaml_content = yaml.safe_load(f)

yaml_content['train'] = f"{project_location}data/coco128/images/train"
yaml_content['val'] = f"{project_location}data/coco128/images/val"
yaml_content['test'] = f"{project_location}data/coco128/images/test"

with open(data_yaml_path, 'w') as f:
    yaml.dump(yaml_content, f, default_flow_style=False)

print(f"[OK] data.yaml updated with train/val/test splits")

# COMMAND ----------

# DBTITLE 1,Infer MLflow Model Signature
# Input: base64-encoded images | Output: class, confidence, bounding boxes (11 columns)
sample_images = glob.glob(f"{project_location}data/coco128/images/train/*.jpg")
if not sample_images:
    raise ValueError("No sample images found. Run the dataset preparation cells first.")

signature, input_example = infer_model_signature(pretrained_model_path, sample_images[0])
print(f"\n[OK] input_example shape: {input_example.shape}, columns: {list(input_example.columns)}")

# COMMAND ----------

# DBTITLE 1,Configure MLflow Experiment and Autologging
# Ultralytics' MLflow callback starts/ends the training run inside model.train()
settings.update({"mlflow": True})
mlflow.autolog(disable=False)

# Default: /Workspace/Shared/Experiments_YOLO_CoCo
experiment_name, experiment_id = setup_mlflow_experiment(
    use_workspaceUsers_path=False, expt_name_suffix="Experiments_YOLO_CoCo"
)

# COMMAND ----------

# DBTITLE 1,Train YOLO with MLflow Tracking
# Close any active MLflow runs so Ultralytics starts a fresh one
mlflow.end_run()

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
tmp_project_location_unique = f"/tmp/training_results_{uuid.uuid4().hex[:8]}/"
os.makedirs(tmp_project_location_unique, exist_ok=True)

model_task = "detection"
model_arch = "yolo11n"
dataset_name = "coco128"

# GPU-aware batch size (YOLO11n @640: batch 8 ~2.5GB | 16 ~4.5GB | 32 ~8GB)
_gpu_name = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu"
_vram_gb = torch.cuda.get_device_properties(0).total_memory / 1e9 if torch.cuda.is_available() else 0
if _vram_gb >= 70:      # H100
    batch_size = 32
elif _vram_gb >= 20:    # A10G
    batch_size = 16
else:
    batch_size = 8

# Training hyperparameters
epochs = 100
learning_rate = 0.001
patience = 5
dropout = 0.2
weight_decay = 0.0005

print(f"[GPU] {_gpu_name} ({_vram_gb:.0f} GB VRAM) -> batch_size={batch_size}")
print(f"Model: {registered_model_name} | Epochs: {epochs} | lr0: {learning_rate}\n")

model = YOLO(pretrained_model_path)
results = model.train(
    task="detect",
    batch=batch_size,
    device=0,
    data=data_yaml_path,
    epochs=epochs,
    lr0=learning_rate,
    project=tmp_project_location_unique,
    name=f"run_{timestamp}",
    exist_ok=True,
    fliplr=1,
    flipud=1,
    perspective=0.001,
    degrees=0.45,
    amp=True,
    patience=patience,
    dropout=dropout,
    weight_decay=weight_decay,
    save=True,
    save_period=10
)

run_id = mlflow.last_active_run().info.run_id
print(f"\n[OK] Training complete! MLflow Run ID: {run_id}")

# Copy training outputs to the UC volume
training_run_dir = os.path.join(tmp_project_location_unique, f"run_{timestamp}")
organized_run_name = f"{model_task}_{model_arch}_{dataset_name}_{timestamp}_run_{run_id}"
volume_run_dir = os.path.join(project_location, "runs", organized_run_name)
if os.path.exists(training_run_dir):
    shutil.copytree(training_run_dir, os.path.join(volume_run_dir, "train"), dirs_exist_ok=True)
    print(f"   [OK] Training outputs copied to: {volume_run_dir}/train")

# YOLO validation metrics
val_metrics_dir = os.path.join(tmp_project_location_unique, "validation_metrics")
os.makedirs(val_metrics_dir, exist_ok=True)
val_results = model.val(project=tmp_project_location_unique, name="validation_metrics")
if os.path.exists(val_metrics_dir):
    shutil.copytree(val_metrics_dir, os.path.join(volume_run_dir, "validation_metrics"), dirs_exist_ok=True)

# Save best weights and register to Unity Catalog
best_model_path = f"/tmp/best_yolo_model_{timestamp}.pt"
YOLO(str(model.trainer.best)).save(best_model_path)

registered_model_name = register_yolo_model(
    run_id=run_id,
    model_path=best_model_path,
    catalog_name=catalog_name,
    schema_name=schema_name,
    model_name=model_name,
    signature=signature,
    input_example=input_example,
    data_yaml_path=data_yaml_path
)

# COMMAND ----------

# DBTITLE 1,Tag Model Version and Set Challenger Alias
# Hand-off to downstream notebooks: tags carry run context, alias marks the candidate
client = MlflowClient()
run_versions = [mv for mv in client.search_model_versions(f"name='{registered_model_name}'")
                if mv.run_id == run_id]
if not run_versions:
    raise RuntimeError(f"No version of {registered_model_name} found for run {run_id}")
model_version = str(max(int(mv.version) for mv in run_versions))

version_tags = {
    "training_run_id": run_id,
    "organized_run_name": organized_run_name,
    "volume_run_dir": volume_run_dir,
    "data_yaml_path": data_yaml_path,
    "gpu": _gpu_name,
    "evaluation_status": "pending",
}
for k, v in version_tags.items():
    client.set_model_version_tag(registered_model_name, model_version, k, str(v))

client.set_registered_model_alias(registered_model_name, CANDIDATE_ALIAS, model_version)

print(f"[OK] {registered_model_name} v{model_version} -> alias '{CANDIDATE_ALIAS}'")
print(f"   Run: {mlflow.get_tracking_uri()}/#/experiments/{experiment_id}/runs/{run_id}")
print(f"   Artifacts: {volume_run_dir}")
print(f"\n[Next] Run 02_evaluation")