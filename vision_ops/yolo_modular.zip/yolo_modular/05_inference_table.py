# Databricks notebook source
# DBTITLE 1,Overview
# MAGIC %md
# MAGIC # 05 - AI Gateway inference table
# MAGIC
# MAGIC Turns on AI Gateway inference tables for the serving endpoint, so request and response payloads are logged to `<catalog>.<schema>.<endpoint_name>_payload`. Any existing AI Gateway settings (usage tracking, rate limits, guardrails) are kept.
# MAGIC
# MAGIC **Notes**
# MAGIC - The table may not appear until the first request reaches the endpoint (run `06_endpoint_testing`).
# MAGIC - Logged requests usually show up after a 2-5 minute delay.
# MAGIC
# MAGIC **Compute:** any serverless (no GPU needed).
# MAGIC
# MAGIC **Next:** `06_endpoint_testing`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./00_config

# COMMAND ----------

# DBTITLE 1,Enable AI Gateway Inference Table
import time
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import AiGatewayInferenceTableConfig

w = WorkspaceClient()


def wait_until_not_updating(name, max_wait_s=600, poll_s=10):
    elapsed = 0
    while True:
        ep = w.serving_endpoints.get(name)
        cu = ep.state.config_update.value if ep.state and ep.state.config_update else "UNKNOWN"
        if cu != "IN_PROGRESS" or elapsed >= max_wait_s:
            return ep
        time.sleep(poll_s)
        elapsed += poll_s


endpoint = wait_until_not_updating(endpoint_name)
if endpoint.state.ready.value != "READY":
    raise RuntimeError(f"Endpoint '{endpoint_name}' is not READY ({endpoint.state.ready.value}) - finish 04_deployment first")

gw = endpoint.ai_gateway
current_cfg = gw.inference_table_config if gw else None

if current_cfg and current_cfg.enabled:
    print(f"[INFO] Inference table already enabled: "
          f"{current_cfg.catalog_name}.{current_cfg.schema_name}.{current_cfg.table_name_prefix}_payload")
else:
    print(f"[INFO] Enabling AI Gateway inference table on '{endpoint_name}'...")
    w.serving_endpoints.put_ai_gateway(
        name=endpoint_name,
        inference_table_config=AiGatewayInferenceTableConfig(
            catalog_name=catalog_name,
            schema_name=schema_name,
            table_name_prefix=inference_table_prefix,
            enabled=True
        ),
        # keep any other AI Gateway settings that were already configured
        usage_tracking_config=gw.usage_tracking_config if gw else None,
        rate_limits=gw.rate_limits if gw else None,
        guardrails=gw.guardrails if gw else None,
    )
    time.sleep(5)
    endpoint = wait_until_not_updating(endpoint_name)
    print("[OK] AI Gateway configuration applied")

# COMMAND ----------

# DBTITLE 1,Verify Inference Table Configuration
endpoint = w.serving_endpoints.get(endpoint_name)
cfg = endpoint.ai_gateway.inference_table_config if endpoint.ai_gateway else None

if not (cfg and cfg.enabled):
    raise RuntimeError("AI Gateway inference table is not enabled")

configured_table = f"{cfg.catalog_name}.{cfg.schema_name}.{cfg.table_name_prefix}_payload"
print(f"[OK] AI Gateway inference table enabled: {configured_table}")

if spark.catalog.tableExists(configured_table):
    print("   Table exists in Unity Catalog")
else:
    print("   Table not created yet - it appears after the first request (run 06_endpoint_testing)")
print("\n[Next] Run 06_endpoint_testing")