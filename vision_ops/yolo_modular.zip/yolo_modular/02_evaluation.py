# Databricks notebook source
# DBTITLE 1,Overview
# MAGIC %md
# MAGIC # 02 - Model evaluation
# MAGIC
# MAGIC Evaluates a registered model version (default: the **`challenger`** alias) on the validation and test splits, runs a local pyfunc test with base64 input (the same path the serving endpoint uses), and records `evaluation_status` = `passed` / `failed` as a model version tag.
# MAGIC
# MAGIC **MLflow deployment job:** use this notebook as the evaluation task with parameters `model_name = {{job.parameters.model_name}}` and `model_version = {{job.parameters.model_version}}`. Run on its own, leave `model_name` as the short name and `model_version` blank to evaluate the `challenger` version.
# MAGIC
# MAGIC **Compute:** Serverless GPU with base environment **AI v6**.
# MAGIC
# MAGIC **Next:** `03_approval`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./00_config

# COMMAND ----------

# DBTITLE 1,Load Shared Helpers
# MAGIC %run ./00_helpers

# COMMAND ----------

# DBTITLE 1,Resolve Model Version
# model_version: version number (set by the deployment job) or alias; blank = challenger
dbutils.widgets.text("model_version", "", "Model Version (blank = challenger)")
dbutils.widgets.text("min_map50_95", "0.0", "Min mAP50-95 to pass")

mv = resolve_model_version(dbutils.widgets.get("model_version"))
model_version = mv.version
run_id = mv.run_id
version_tags = mv.tags or {}

organized_run_name = version_tags.get("organized_run_name", f"v{model_version}_run_{run_id}")
volume_run_dir = version_tags.get("volume_run_dir",
                                  os.path.join(project_location, "runs", organized_run_name))

print(f"[OK] Evaluating {registered_model_name} v{model_version}")
print(f"   Run ID: {run_id}")
print(f"   Artifacts: {volume_run_dir}")

# COMMAND ----------

# DBTITLE 1,Validation Set Evaluation
# Load the raw YOLO weights logged with the model
model_dir = mlflow.artifacts.download_artifacts(f"runs:/{run_id}/model")
pt_files = glob.glob(f"{model_dir}/**/*.pt", recursive=True)
if not pt_files:
    raise FileNotFoundError(f"No .pt file found in runs:/{run_id}/model")

loaded_model = YOLO(pt_files[0], task='detect')
print(f"[OK] Model loaded from MLflow\n")

evaluate_model_on_split(
    model=loaded_model,
    image_dir=f"{project_location}data/coco128/images/val",
    split_name="validation",
    output_dir=os.path.join(volume_run_dir, "validation_samples"),
    run_id=run_id,
    registered_model_name=registered_model_name,
    organized_run_name=organized_run_name,
    num_samples=3
)

# COMMAND ----------

# DBTITLE 1,Test Set Evaluation
evaluate_model_on_split(
    model=loaded_model,
    image_dir=f"{project_location}data/coco128/images/test",
    split_name="test",
    output_dir=os.path.join(volume_run_dir, "test_samples"),
    run_id=run_id,
    registered_model_name=registered_model_name,
    organized_run_name=organized_run_name,
    num_samples=3
)

# COMMAND ----------

# DBTITLE 1,Test Registered Model (Local PyFunc, Base64 Input)
import base64
import numpy as np
import matplotlib.patches as patches
from PIL import Image

print("=" * 60)
print("LOCAL MODEL TEST - BASE64 INPUT")
print("=" * 60)

local_test_passed = False

# Load exactly as the serving endpoint does
serving_model = mlflow.pyfunc.load_model(f"models:/{registered_model_name}/{model_version}")
print(f"[OK] MLflow pyfunc model v{model_version} loaded\n")

test_images = glob.glob(f"{project_location}data/coco128/images/test/*.jpg")
if not test_images:
    raise FileNotFoundError("No test images found - run 01_data_prep_and_training first")

# Use images 10-12 (different from the test_samples evaluation, which uses the first 3)
sample_images = test_images[10:13] or test_images[:3]
num_samples = len(sample_images)
colors = plt.cm.tab20(np.linspace(0, 1, 20))

fig, axes = plt.subplots(1, num_samples, figsize=(15, 5))
if num_samples == 1:
    axes = [axes]

for i, test_image_path in enumerate(sample_images):
    with open(test_image_path, 'rb') as f:
        image_base64 = base64.b64encode(f.read()).decode('utf-8')

    predictions = serving_model.predict(pd.DataFrame({"image_base64": [image_base64]}))

    axes[i].imshow(Image.open(test_image_path))
    axes[i].axis('off')
    for _, row in predictions.iterrows():
        x1, y1, x2, y2 = row['bbox_x1'], row['bbox_y1'], row['bbox_x2'], row['bbox_y2']
        color = colors[int(row['class_num']) % len(colors)]
        axes[i].add_patch(patches.Rectangle((x1, y1), x2 - x1, y2 - y1,
                                            linewidth=2, edgecolor=color, facecolor='none'))
        axes[i].text(x1, y1 - 5, f"{row['class_name']} {row['confidence']:.2f}",
                     color='white', fontsize=8, bbox=dict(facecolor=color, alpha=0.8, pad=2))
    axes[i].set_title(f"{os.path.basename(test_image_path)}\n{len(predictions)} objects", fontsize=10)
    print(f"Sample {i+1}/{num_samples}: {os.path.basename(test_image_path)} -> {len(predictions)} detections")

plt.tight_layout()
plt.suptitle(f"Local Serving Test - MLflow PyFunc with Base64 (v{model_version})", fontsize=14, y=1.02)
plt.show()

local_test_passed = True
print("\n[OK] Local pyfunc test passed")

# COMMAND ----------

# DBTITLE 1,Record Evaluation Result
from datetime import datetime, timezone

client = MlflowClient()
run_metrics = client.get_run(run_id).data.metrics
map_key = next((k for k in run_metrics if "mAP50-95" in k), None)
map50_95 = run_metrics.get(map_key) if map_key else None
min_map = float(dbutils.widgets.get("min_map50_95"))

if map50_95 is None:
    print("[WARNING] mAP50-95 not found in run metrics")
    metric_ok = min_map <= 0
else:
    print(f"mAP50-95 ({map_key}): {map50_95:.4f}  (threshold {min_map})")
    metric_ok = map50_95 >= min_map

evaluation_status = "passed" if (local_test_passed and metric_ok) else "failed"

client.set_model_version_tag(registered_model_name, model_version, "evaluation_status", evaluation_status)
client.set_model_version_tag(registered_model_name, model_version, "evaluated_at",
                             datetime.now(timezone.utc).isoformat())
if map50_95 is not None:
    client.set_model_version_tag(registered_model_name, model_version, "eval_map50_95", f"{map50_95:.4f}")

print(f"\n[{evaluation_status.upper()}] {registered_model_name} v{model_version}")
if evaluation_status != "passed":
    raise RuntimeError("Evaluation failed - model version will not be eligible for approval")
print("[Next] Run 03_approval")