# Databricks notebook source
# DBTITLE 1,Overview
# MAGIC %md
# MAGIC # 06 - Test the deployed endpoint
# MAGIC
# MAGIC Sends a random test image (base64) to the serving endpoint, draws the returned bounding boxes, summarizes the detections, and checks the AI Gateway inference table for logged requests.
# MAGIC
# MAGIC **Compute:** any serverless (no GPU needed).

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./00_config

# COMMAND ----------

# DBTITLE 1,Test Deployed Endpoint
import os
import json
import base64
import glob
import random
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

endpoint = w.serving_endpoints.get(endpoint_name)
if endpoint.state.ready.value != "READY":
    raise RuntimeError(f"Endpoint '{endpoint_name}' is not READY ({endpoint.state.ready.value})")
served = endpoint.config.served_entities[0]
print(f"Endpoint: {endpoint_name} -> {served.entity_name} v{served.entity_version}\n")

test_images = glob.glob(f"{project_location}data/coco128/images/test/*.jpg")
if not test_images:
    raise FileNotFoundError("No test images found - run 01_data_prep_and_training first")

test_image_path = random.choice(test_images)
print(f"Test image: {os.path.basename(test_image_path)} (random from {len(test_images)} test images)")

with open(test_image_path, 'rb') as f:
    image_base64 = base64.b64encode(f.read()).decode('utf-8')

response = w.serving_endpoints.query(
    name=endpoint_name,
    dataframe_records=[{"image_base64": image_base64}]
)
response_dict = response.as_dict()

print("[OK] Endpoint test successful!\n")
print("Response preview:")
print(json.dumps(response_dict, indent=2)[:500])

# COMMAND ----------

# DBTITLE 1,Visualize Endpoint Predictions
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image

img = Image.open(test_image_path)
fig, (ax_orig, ax) = plt.subplots(1, 2, figsize=(20, 9))

ax_orig.imshow(img)
ax_orig.set_title("Original", fontsize=13)
ax_orig.axis("off")
ax.imshow(img)

# predictions: list of detection dicts, or a list wrapping one list of dicts
predictions = response_dict.get("predictions", [])
if isinstance(predictions, list) and len(predictions) > 0 and isinstance(predictions[0], list):
    detections = predictions[0]
else:
    detections = predictions if isinstance(predictions, list) else []

unique_classes = list({d.get("class_name", "?") for d in detections})
cmap = plt.get_cmap("tab10", max(len(unique_classes), 1))
class_colors = {cls: cmap(i) for i, cls in enumerate(unique_classes)}

for det in detections:
    x1, y1 = det.get("bbox_x1", 0), det.get("bbox_y1", 0)
    x2, y2 = det.get("bbox_x2", 0), det.get("bbox_y2", 0)
    cls_name = det.get("class_name", "?")
    color = class_colors.get(cls_name, "lime")
    ax.add_patch(patches.Rectangle((x1, y1), x2 - x1, y2 - y1,
                                   linewidth=2, edgecolor=color, facecolor="none"))
    ax.text(x1, y1 - 4, f"{cls_name} {det.get('confidence', 0):.2f}", fontsize=9, color="white",
            bbox=dict(facecolor=color, alpha=0.7, pad=1, edgecolor="none"))

ax.set_title(f"Endpoint Detections - {len(detections)} objects", fontsize=13)
ax.axis("off")
plt.tight_layout()
plt.show()

print(f"[INFO] {len(detections)} detections | Classes: {', '.join(sorted(unique_classes))}")

# COMMAND ----------

# DBTITLE 1,Detection Summary Table
import pandas as pd

if len(detections) == 0:
    print("[INFO] No detections returned by the endpoint for this image.")
else:
    det_df = pd.DataFrame(detections)

    summary_df = (
        det_df.groupby("class_name")
        .agg(
            count=("confidence", "size"),
            avg_confidence=("confidence", "mean"),
            min_confidence=("confidence", "min"),
            max_confidence=("confidence", "max"),
        )
        .round(3)
        .reset_index()
        .sort_values("count", ascending=False)
        .reset_index(drop=True)
    )
    print(f"[Per-class summary] {len(detections)} detections across {summary_df.shape[0]} class(es)")
    display(summary_df)

    detail_cols = [c for c in ["class_name", "confidence", "bbox_x1", "bbox_y1", "bbox_x2", "bbox_y2"] if c in det_df.columns]
    detail_df = det_df[detail_cols].round(2).sort_values("confidence", ascending=False).reset_index(drop=True)
    print("[Per-detection detail]")
    display(detail_df)

# COMMAND ----------

# DBTITLE 1,Check Inference Table Logging
# Logged requests usually appear 2-5 minutes after the request
quoted_table = ".".join(f"`{p}`" for p in inference_table_name.split("."))

if spark.catalog.tableExists(inference_table_name):
    display(spark.sql(f"SELECT * FROM {quoted_table} ORDER BY timestamp_ms DESC LIMIT 10"))
else:
    print(f"[INFO] {inference_table_name} not created yet - wait a few minutes and re-run this cell")