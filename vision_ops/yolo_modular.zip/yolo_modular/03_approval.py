# Databricks notebook source
# DBTITLE 1,Overview
# MAGIC %md
# MAGIC # 03 - Deployment approval
# MAGIC
# MAGIC Approval task for an **MLflow 3 deployment job**. There is no approval flag in this notebook. Approval comes from a Unity Catalog model version tag set by the **Approve** button on the model version page.
# MAGIC
# MAGIC **How it works**
# MAGIC 1. The deployment job is triggered for a new model version and passes the `model_name` and `model_version` job parameters.
# MAGIC 2. On the first run this task **fails on purpose**, because the version has no approval tag yet.
# MAGIC 3. A reviewer checks the evaluation results on the model version page and clicks **Approve**. This sets the tag `<approval task name> = Approved` and automatically repairs the job run.
# MAGIC 4. On the repaired run this task passes, points the **`champion`** alias at the version, and the job continues to deployment.
# MAGIC
# MAGIC **Job setup for this task**
# MAGIC - The task name must start with `approval` (for example `Approval_Check`).
# MAGIC - Task parameters: `model_name = {{job.parameters.model_name}}`, `model_version = {{job.parameters.model_version}}`, `approval_tag_name = {{task.name}}`.
# MAGIC - Set retries to 0, because the first failure is expected.
# MAGIC
# MAGIC Only versions with `evaluation_status = passed` (set by `02_evaluation`) can pass this task.
# MAGIC
# MAGIC **Compute:** any serverless (no GPU needed).
# MAGIC
# MAGIC **Next:** `04_deployment`

# COMMAND ----------

# DBTITLE 1,Deployment Job Parameters
# Parameters supplied by the MLflow deployment job.
# This notebook does not %run 00_config: the deployment job passes the
# full three-level model name, not the short name used by 00_config.
import mlflow
from mlflow import MlflowClient

dbutils.widgets.text("model_name", "", "Model Name (catalog.schema.model)")
dbutils.widgets.text("model_version", "", "Model Version")
dbutils.widgets.text("approval_tag_name", "Approval_Check", "Approval Tag Name (= task name)")

registered_model_name = dbutils.widgets.get("model_name").strip()
model_version = dbutils.widgets.get("model_version").strip()
approval_tag_name = dbutils.widgets.get("approval_tag_name").strip()

if registered_model_name.count(".") != 2:
    raise ValueError(f"model_name must be catalog.schema.model, got '{registered_model_name}'")
if not model_version.isdigit():
    raise ValueError(f"model_version must be a version number, got '{model_version}'")
if not approval_tag_name:
    raise ValueError("approval_tag_name is required (pass {{task.name}})")

mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()
CHAMPION_ALIAS = "champion"   # served by 04_deployment

# COMMAND ----------

# DBTITLE 1,Review Candidate
mv = client.get_model_version(registered_model_name, model_version)
tags = mv.tags or {}

try:
    current_champion = client.get_model_version_by_alias(registered_model_name, CHAMPION_ALIAS).version
except Exception:
    current_champion = None

print("=" * 60)
print("DEPLOYMENT APPROVAL - CANDIDATE REVIEW")
print("=" * 60)
print(f"   Model:             {registered_model_name}")
print(f"   Candidate version: {mv.version}")
print(f"   Training run:      {mv.run_id}")
print(f"   Evaluation status: {tags.get('evaluation_status', 'missing')}")
print(f"   mAP50-95:          {tags.get('eval_map50_95', 'n/a')}")
print(f"   Evaluated at:      {tags.get('evaluated_at', 'n/a')}")
print(f"   Current champion:  {current_champion or 'none'}")
print(f"   Approval tag:      {approval_tag_name} = {tags.get(approval_tag_name, '<not set>')}")

# COMMAND ----------

# DBTITLE 1,Approval Gate
from datetime import datetime, timezone

if tags.get("evaluation_status") != "passed":
    raise RuntimeError(f"v{mv.version} has not passed evaluation - run 02_evaluation first")

# Approval is read from the UC tag set by the 'Approve' button on the model version page.
# Failing here is expected on the first run; clicking Approve repairs the run from this task.
if tags.get(approval_tag_name, "").strip().lower() != "approved":
    raise Exception(
        f"Model version {mv.version} is not approved for deployment. "
        f"Review it on the model version page and click Approve "
        f"(sets tag '{approval_tag_name}' = 'Approved'). Champion unchanged ({current_champion or 'none'})."
    )

client.set_registered_model_alias(registered_model_name, CHAMPION_ALIAS, mv.version)
if "approved_at" not in tags:
    client.set_model_version_tag(registered_model_name, mv.version, "approved_at",
                                 datetime.now(timezone.utc).isoformat())

print(f"[OK] APPROVED: {registered_model_name} v{mv.version} -> alias '{CHAMPION_ALIAS}'")