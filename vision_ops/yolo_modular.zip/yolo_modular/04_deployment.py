# Databricks notebook source
# DBTITLE 1,Overview
# MAGIC %md
# MAGIC # 04 - Model deployment
# MAGIC
# MAGIC Creates or updates the Model Serving endpoint so it serves the **`champion`** version (set by `03_approval`). If the endpoint already serves that version, nothing changes. AI Gateway inference tables are configured separately in `05_inference_table`.
# MAGIC
# MAGIC **MLflow deployment job:** use this notebook as the deployment task (after the approval task) with parameters `model_name = {{job.parameters.model_name}}` and `model_version = {{job.parameters.model_version}}`. The version must be the current `champion`, which `03_approval` sets once the version is approved. Run on its own, leave `model_version` blank to deploy the `champion` version.
# MAGIC
# MAGIC **Compute:** any serverless (no GPU needed).
# MAGIC
# MAGIC **Next:** `05_inference_table`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./00_config

# COMMAND ----------

# DBTITLE 1,Resolve Version and Endpoint Helpers
import time
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound
from databricks.sdk.service.serving import ServedEntityInput, EndpointCoreConfigInput

dbutils.widgets.text("model_version", "", "Model Version (blank = champion)")
dbutils.widgets.text("max_wait_minutes", "30", "Max wait for endpoint (minutes)")
max_wait_s = int(dbutils.widgets.get("max_wait_minutes")) * 60
requested_version = dbutils.widgets.get("model_version").strip()

w = WorkspaceClient()
client = MlflowClient()

try:
    champion_version = client.get_model_version_by_alias(registered_model_name, CHAMPION_ALIAS).version
except Exception as e:
    raise RuntimeError(f"No '{CHAMPION_ALIAS}' alias on {registered_model_name} - run 03_approval first") from e

# Only approved versions can be deployed: the requested version (deployment job) must be the champion
if requested_version and requested_version != str(champion_version):
    raise RuntimeError(
        f"v{requested_version} is not the approved '{CHAMPION_ALIAS}' (currently v{champion_version}) - "
        f"it must pass 03_approval before deployment"
    )
model_version = str(champion_version)


def endpoint_state(ep):
    cu = ep.state.config_update.value if ep.state and ep.state.config_update else "UNKNOWN"
    rd = ep.state.ready.value if ep.state and ep.state.ready else "UNKNOWN"
    return cu, rd


def wait_until_not_updating(name, max_wait_s, poll_s=15):
    """Poll until the endpoint config is no longer updating (or timeout)."""
    elapsed = 0
    while True:
        ep = w.serving_endpoints.get(name)
        cu, rd = endpoint_state(ep)
        if cu != "IN_PROGRESS" or elapsed >= max_wait_s:
            return ep
        if elapsed % 60 == 0:
            print(f"   Status: config={cu}, ready={rd} ({elapsed}s elapsed)")
        time.sleep(poll_s)
        elapsed += poll_s


print(f"[OK] Deploying {registered_model_name} v{model_version} ('{CHAMPION_ALIAS}') to '{endpoint_name}'")

# COMMAND ----------

# DBTITLE 1,Create or Update Serving Endpoint
served_entities = [
    ServedEntityInput(
        entity_name=registered_model_name,
        entity_version=str(model_version),
        workload_size="Small",
        scale_to_zero_enabled=True
    )
]

try:
    existing = w.serving_endpoints.get(endpoint_name)
except NotFound:
    existing = None

if existing is None:
    print(f"[INFO] Endpoint '{endpoint_name}' does not exist - creating...")
    w.serving_endpoints.create(
        name=endpoint_name,
        config=EndpointCoreConfigInput(name=endpoint_name, served_entities=served_entities)
    )
else:
    # Let any in-flight update finish before changing the config
    existing = wait_until_not_updating(endpoint_name, max_wait_s)
    current = existing.config.served_entities[0] if existing.config and existing.config.served_entities else None
    if current and current.entity_name == registered_model_name and current.entity_version == str(model_version):
        print(f"[INFO] Already serving {registered_model_name} v{model_version} - no update needed")
    else:
        if current:
            print(f"[INFO] Updating {current.entity_name} v{current.entity_version} -> v{model_version}")
        w.serving_endpoints.update_config(name=endpoint_name, served_entities=served_entities)

print(f"\n[INFO] Waiting up to {max_wait_s // 60} min (provisioning can take 10-20+ min)...")
endpoint = wait_until_not_updating(endpoint_name, max_wait_s)
cu, rd = endpoint_state(endpoint)

workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
print("\n" + "=" * 60)
print(f"   Endpoint:     {endpoint_name}")
print(f"   Model:        {registered_model_name} (v{model_version})")
print(f"   Config state: {cu}")
print(f"   Ready state:  {rd}")
print(f"   URL:          https://{workspace_url}/ml/endpoints/{endpoint_name}")
print("=" * 60)

if cu == "UPDATE_FAILED":
    raise RuntimeError("Endpoint update failed - check the endpoint UI for details")
if cu == "IN_PROGRESS":
    print("[INFO] Still provisioning - re-run this cell later, then run 05_inference_table")
else:
    client.set_model_version_tag(registered_model_name, model_version, "deployed_endpoint", endpoint_name)
    print("[Next] Run 05_inference_table")