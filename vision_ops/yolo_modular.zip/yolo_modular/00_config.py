# Databricks notebook source
# DBTITLE 1,Shared Configuration
# ============================================================
# SHARED CONFIGURATION
# ============================================================
# Included by every notebook in this folder via `%run ./00_config`.
# Lightweight: only needs mlflow + databricks-sdk (no GPU / ultralytics).
#
# Hand-off between notebooks happens through Unity Catalog model
# version aliases and tags (no shared Python state needed):
#   01_data_prep_and_training -> sets alias 'challenger' + run tags
#   02_evaluation             -> sets tag 'evaluation_status'
#   03_approval               -> sets alias 'champion'
#   04/05/06                  -> act on the 'champion' version
#
# MLflow deployment jobs pass `model_name` as the full
# catalog.schema.model name; that form is accepted too and overrides
# the catalog_name / schema_name widgets.
# ============================================================

import mlflow
from mlflow import MlflowClient

dbutils.widgets.text("catalog_name", "classic_stable_yq2l1o_catalog", "Catalog Name")
dbutils.widgets.text("schema_name", "yolo_cv_workshop", "Schema Name")
dbutils.widgets.text("volume_name", "yolo_sgc", "Volume Name")
dbutils.widgets.text("model_name", "yolo11n_coco128_sgc", "Model Name (short or catalog.schema.model)")

catalog_name = dbutils.widgets.get("catalog_name")
schema_name = dbutils.widgets.get("schema_name")
volume_name = dbutils.widgets.get("volume_name")
model_name = dbutils.widgets.get("model_name").strip()

# Accept the full three-level name passed by an MLflow deployment job
_name_parts = model_name.split(".")
if len(_name_parts) == 3:
    catalog_name, schema_name, model_name = _name_parts
elif len(_name_parts) != 1:
    raise ValueError(f"model_name must be 'model' or 'catalog.schema.model', got '{model_name}'")

mlflow.set_registry_uri("databricks-uc")

# Derived names
registered_model_name = f"{catalog_name}.{schema_name}.{model_name}"
project_location = f"/Volumes/{catalog_name}/{schema_name}/{volume_name}/"
endpoint_name = f"{model_name}_endpoint"
inference_table_prefix = endpoint_name
inference_table_name = f"{catalog_name}.{schema_name}.{endpoint_name}_payload"

# Model registry aliases used as the hand-off between notebooks
CANDIDATE_ALIAS = "challenger"   # set by 01 after registration
CHAMPION_ALIAS = "champion"      # set by 03 after approval


def resolve_model_version(version_or_alias=""):
    """Return a UC ModelVersion by number or alias (blank = challenger alias)."""
    client = MlflowClient()
    ref = (version_or_alias or "").strip() or CANDIDATE_ALIAS
    if ref.isdigit():
        return client.get_model_version(registered_model_name, ref)
    return client.get_model_version_by_alias(registered_model_name, ref)


print("[Configuration]")
print(f"   Registered model: {registered_model_name}")
print(f"   Volume path:      {project_location}")
print(f"   Endpoint:         {endpoint_name}")
print(f"   Inference table:  {inference_table_name}")